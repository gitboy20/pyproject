likes_pineapple_on_pizza = "NO"

if(likes_pineapple_on_pizza == "Absolutely!"):
    print("You are weird!")
elif(likes_pineapple_on_pizza == "Sort of"):
    print("I guess you're ok")
else:
    print("you are completely normal")