# # Shopping list
# shopping_list = ["eggs", "potato", "quinoa"]
# print(shopping_list)

# shopping_list.append("toilet paper")
# print(shopping_list)

# print(shopping_list[1])

# shopping_list.remove("eggs")
# print(shopping_list)

# moms_shopping_list = ["dog food", "bag of ice", "tissues", "corn"]
# shopping_list.extend(moms_shopping_list)
# print(shopping_list)

# print("mom's shopping list")
# print(moms_shopping_list)

# my_shopping_list = shopping_list[0:3]
# sisters_shopping_list = shopping_list[3:7]

# print("My shopping list contains")
# print(my_shopping_list)

# print("My sister's shopping list contains")
# print(sisters_shopping_list)

# Visual studio code shortcut for commenting out multiple lines: CTRL + /

# tup1=('January', 'February', 'March')
# print(tup1)

# tup1.append("VIRUS MONTH")

player = {
    "name": 'Prince Chagum',
    "hometown": "Kanbal",
    "weaknesses": ["swords", "dragons"]
}
print(player)
name_of_player = player["name"]
print("Hello, " + name_of_player + "! Welcome to the simulator!")
print("You are from the hometown of "+player['hometown'])
print("Your weaknesses are: " + str(player['weaknesses']))

print("My age is " + str(3))
print(5+5)