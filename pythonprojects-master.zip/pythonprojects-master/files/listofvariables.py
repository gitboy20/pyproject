name="IG-11"
race="Droid"
powers=["bulletproof"]