print(23/2)
print(12.5+10)
print(5.0+5)

# integer / integer = float or integer
# integer + float = float

# How to do powers in python
print(((4**2)**2-64)/8)


#Yasin
print(((4**2)**2-64)/8)

#Experiment
print(4**2**2-64/8)

#Aziz
print((4*2)**2-64)
















print((((4**2)**2) - 64) / 8)

# assigning a variable to itself with another mathematical function applied to itself
variable1 = 5
variable1 = variable1 ** 3
print(variable1)

a = 2
a = (a ** a / a + a)
print("value of a: "+ str(a))















a = 20
b = 10
a = a/b
print(a)


a = 2
#7
a = a + 10
print(a)
#8
a = a / 3
print(a)
#9
a = a ** 4
print(a)

# 10
a = 40
b = 20
b = b-a
print(b)

# 11
import math
x = math.sqrt(81)
print(x)
print(math.sqrt(144))

# 12
print(math.sqrt(512/2))

# 13
a = 4
b = 5
c = math.sqrt((4**2) + (5**2))

# c^2 = a^2 + b^2
# c = sqrt(a^2 + b^2)
print(c)
